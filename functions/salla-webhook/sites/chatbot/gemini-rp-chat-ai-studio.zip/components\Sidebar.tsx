import React from 'react';
import { Character, Settings, SidebarTab, WorldInfo } from '../types';

type Setter<T> = T | ((prev: T) => T);

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: SidebarTab;
  setActiveTab: (tab: SidebarTab) => void;
  characters: Character[];
  onNewCharacter: () => void;
  onEditCharacter: (character: Character) => void;
  worldInfo: WorldInfo;
  setWorldInfo: (value: Setter<WorldInfo>) => void;
  settings: Settings;
  setSettings: (value: Setter<Settings>) => void;
  onClearChat: () => void;
  isVeoKeySelected: boolean;
  onSelectVeoKey: () => void;
  onUserPortraitChange: (dataUrl: string) => void;
}

const tabs: { id: SidebarTab; label: string }[] = [
  { id: 'chars', label: 'Characters' },
  { id: 'world', label: 'World' },
  { id: 'setup', label: 'Setup' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  characters,
  onNewCharacter,
  onEditCharacter,
  worldInfo,
  setWorldInfo,
  settings,
  setSettings,
  onClearChat,
  isVeoKeySelected,
  onSelectVeoKey,
  onUserPortraitChange,
}) => {
  const handlePortraitUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      onUserPortraitChange(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 w-full max-w-sm transform border-r border-white/5 bg-surface/95 shadow-2xl transition-transform duration-300 md:static md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full md:-translate-x-0'}`}
    >
      <div className="flex items-center justify-between border-b border-white/5 px-5 py-4">
        <div>
          <p className="text-xs uppercase tracking-widest text-white/60">Gemini RP</p>
          <h1 className="text-xl font-semibold text-white">Story Controls</h1>
        </div>
        <button onClick={onClose} className="rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20 md:hidden">
          ✕
        </button>
      </div>
      <nav className="flex gap-1 border-b border-white/5 px-4 py-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 rounded-full px-4 py-2 text-sm font-semibold transition ${activeTab === tab.id ? 'bg-primary/20 text-white shadow-glow' : 'text-white/60 hover:text-white'}`}
          >
            {tab.label}
          </button>
        ))}
      </nav>
      <div className="h-[calc(100vh-150px)] overflow-y-auto px-5 py-4">
        {activeTab === 'chars' && (
          <div className="space-y-4">
            <button
              onClick={onNewCharacter}
              className="w-full rounded-2xl border border-dashed border-white/20 p-4 text-left text-white/70 transition hover:border-primary hover:text-white"
            >
              + New character
            </button>
            {characters.length === 0 && <p className="text-sm text-white/50">No characters yet. Create one to begin roleplay.</p>}
            {characters.map((character) => (
              <button
                key={character.id}
                onClick={() => onEditCharacter(character)}
                className="flex w-full items-center gap-3 rounded-2xl bg-white/5 p-4 text-left transition hover:bg-white/10"
              >
                {character.portraitUrl ? (
                  <img src={character.portraitUrl} alt={character.name} className="h-12 w-12 rounded-full object-cover" />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-lg text-white">
                    {character.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div>
                  <p className="font-semibold text-white">{character.name}</p>
                  <p className="text-sm text-white/60">
                    {character.description || 'No description yet.'}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
        {activeTab === 'world' && (
          <div className="space-y-4">
            <label className="space-y-2 text-sm text-white/80">
              <span>Scenario</span>
              <textarea
                className="w-full rounded-2xl border border-white/10 bg-black/30 p-4 text-white focus:border-primary focus:outline-none"
                rows={5}
                value={worldInfo.scenario}
                onChange={(e) => setWorldInfo((prev) => ({ ...prev, scenario: e.target.value }))}
                placeholder="Setting, tone, overarching plot..."
              />
            </label>
            <label className="space-y-2 text-sm text-white/80">
              <span>Story tracker</span>
              <textarea
                className="w-full rounded-2xl border border-white/10 bg-black/30 p-4 text-white focus:border-primary focus:outline-none"
                rows={6}
                value={worldInfo.storyTracker}
                onChange={(e) => setWorldInfo((prev) => ({ ...prev, storyTracker: e.target.value }))}
                placeholder="Important events, unresolved threads, NPC motivations..."
              />
            </label>
          </div>
        )}
        {activeTab === 'setup' && (
          <div className="space-y-5">
            <label className="space-y-2 text-sm text-white/80">
              <span>Model</span>
              <select
                className="w-full rounded-2xl border border-white/10 bg-black/30 p-3 text-white"
                value={settings.modelName}
                onChange={(e) => setSettings((prev) => ({ ...prev, modelName: e.target.value }))}
              >
                {['gemini-2.5-pro', 'gemini-2.0-flash', 'gemini-1.5-pro'].map((model) => (
                  <option key={model} value={model} className="bg-secondary">
                    {model}
                  </option>
                ))}
              </select>
            </label>
            <div className="space-y-2 text-sm text-white/80">
              <p>Memory</p>
              <label className="flex items-center gap-3 rounded-2xl border border-white/10 p-3">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={settings.enableSmarterMemory}
                  onChange={(e) => setSettings((prev) => ({ ...prev, enableSmarterMemory: e.target.checked }))}
                />
                <span>Enable smarter memory (auto-summarize)</span>
              </label>
              <label className="flex items-center gap-3 rounded-2xl border border-white/10 p-3">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={settings.autoNarration}
                  onChange={(e) => setSettings((prev) => ({ ...prev, autoNarration: e.target.checked }))}
                />
                <span>Auto narration after character replies</span>
              </label>
              <label className="flex items-center gap-3 rounded-2xl border border-white/10 p-3">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={!!settings.enableGroupChatter}
                  onChange={(e) => setSettings((prev) => ({ ...prev, enableGroupChatter: e.target.checked }))}
                />
                <span>Group chatter (all characters reply)</span>
              </label>
            </div>
            <div className="space-y-2 text-sm text-white/80">
              <p>User portrait</p>
              <div className="flex items-center gap-3">
                <input type="file" accept="image/*" onChange={handlePortraitUpload} />
                {settings.userPortraitUrl && (
                  <img src={settings.userPortraitUrl} alt="User portrait" className="h-16 w-16 rounded-xl object-cover" />
                )}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 p-4 text-sm text-white/80">
              <p className="font-semibold text-white">Veo video access</p>
              <p className="text-white/60">Status: {isVeoKeySelected ? 'Key selected' : 'No key selected'}</p>
              <button
                className="mt-3 w-full rounded-xl border border-primary/40 px-4 py-2 text-sm font-semibold text-primary transition hover:bg-primary/10"
                onClick={onSelectVeoKey}
              >
                {isVeoKeySelected ? 'Change key' : 'Select key'}
              </button>
            </div>
            <button
              onClick={onClearChat}
              className="w-full rounded-2xl border border-red-400/30 px-4 py-3 text-sm font-semibold text-red-300 transition hover:bg-red-400/10"
            >
              Clear chat history
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};
