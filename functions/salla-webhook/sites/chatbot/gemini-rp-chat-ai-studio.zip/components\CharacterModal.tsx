import React, { useState } from 'react';
import { Character } from '../types';

interface CharacterModalProps {
  character: Character;
  onSave: (character: Character) => void;
  onCancel: () => void;
  onEvolve: (character: Character) => Promise<{ description: string; instructions: string }>;
}

export const CharacterModal: React.FC<CharacterModalProps> = ({ character, onSave, onCancel, onEvolve }) => {
  const [form, setForm] = useState<Character>({ ...character, id: character.id || `char_${Date.now()}` });
  const [isEvolving, setIsEvolving] = useState(false);

  const canSave = form.name.trim().length > 0 && form.description.trim().length > 0;

  const handleChange = (key: keyof Character, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleEvolve = async () => {
    setIsEvolving(true);
    try {
      const updates = await onEvolve(form);
      setForm((prev) => ({ ...prev, ...updates }));
    } catch (error) {
      alert((error as Error).message);
    } finally {
      setIsEvolving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 px-4">
      <div className="w-full max-w-3xl rounded-2xl bg-surface/95 p-6 shadow-glow">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-white">{character.id ? 'Edit character' : 'Create character'}</h2>
          <button onClick={onCancel} className="text-gray-400 transition hover:text-white">✕</button>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <label className="space-y-2 text-sm">
            <span className="text-gray-300">Name</span>
            <input
              className="w-full rounded-lg border border-white/10 bg-black/20 p-3 text-white focus:border-primary focus:outline-none"
              value={form.name}
              onChange={(e) => handleChange('name', e.target.value)}
            />
          </label>
          <label className="space-y-2 text-sm">
            <span className="text-gray-300">Portrait URL (optional)</span>
            <input
              className="w-full rounded-lg border border-white/10 bg-black/20 p-3 text-white focus:border-primary focus:outline-none"
              value={form.portraitUrl || ''}
              onChange={(e) => handleChange('portraitUrl', e.target.value)}
              placeholder="https://"
            />
          </label>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <label className="space-y-2 text-sm">
            <span className="text-gray-300">Description</span>
            <textarea
              className="h-40 w-full rounded-lg border border-white/10 bg-black/20 p-3 text-white focus:border-primary focus:outline-none"
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
            />
          </label>
          <label className="space-y-2 text-sm">
            <span className="text-gray-300">Behavior instructions</span>
            <textarea
              className="h-40 w-full rounded-lg border border-white/10 bg-black/20 p-3 text-white focus:border-primary focus:outline-none"
              value={form.instructions}
              onChange={(e) => handleChange('instructions', e.target.value)}
              placeholder="Tone, pacing, restrictions..."
            />
          </label>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <button
            className="rounded-lg bg-primary px-6 py-3 font-semibold text-white transition hover:shadow-glow disabled:cursor-not-allowed disabled:bg-white/20"
            disabled={!canSave}
            onClick={() => onSave(form)}
          >
            Save
          </button>
          <button
            className="rounded-lg border border-white/20 px-6 py-3 text-white transition hover:bg-white/5"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            className="flex items-center gap-2 rounded-lg border border-primary/50 px-6 py-3 text-primary transition hover:bg-primary/10 disabled:cursor-not-allowed disabled:opacity-60"
            onClick={handleEvolve}
            disabled={isEvolving}
          >
            {isEvolving ? 'Evolving…' : 'Evolve with AI'}
          </button>
        </div>
      </div>
    </div>
  );
};
