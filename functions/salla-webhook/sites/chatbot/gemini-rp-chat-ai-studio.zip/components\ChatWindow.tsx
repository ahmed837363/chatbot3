import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Character, Message, MessagePart, Role } from '../types';

interface ChatWindowProps {
  chatHistory: Message[];
  characters: Character[];
  onSendMessage: (message: string, as: string) => Promise<void | Message> | void;
  onContinue: () => void;
  onStopGeneration: () => void;
  onForceUnlock: () => void;
  onEditMessage: (id: string, newContent: string, part?: MessagePart) => void;
  onDeleteMessage: (id: string) => void;
  onOpenSidebar: () => void;
  isSending: boolean;
  isContinuing: boolean;
  onMakeImage: () => void;
  onMakeVideo: () => void;
  isGeneratingMedia: boolean;
  autoNarration: boolean;
  onToggleAutoNarration: () => void;
}

const roleStyles: Record<Role, string> = {
  [Role.USER]: 'bg-white/5 border-white/10',
  [Role.CHARACTER]: 'bg-primary/10 border-primary/40',
  [Role.NARRATOR]: 'bg-black/30 border-white/10 italic',
  [Role.SYSTEM]: 'bg-red-900/40 border-red-500/30',
};

const roleLabels: Record<Role, string> = {
  [Role.USER]: 'You',
  [Role.CHARACTER]: 'Character',
  [Role.NARRATOR]: 'Narrator',
  [Role.SYSTEM]: 'System',
};

export const ChatWindow: React.FC<ChatWindowProps> = ({
  chatHistory,
  characters,
  onSendMessage,
  onContinue,
  onStopGeneration,
  onForceUnlock,
  onEditMessage,
  onDeleteMessage,
  onOpenSidebar,
  isSending,
  isContinuing,
  onMakeImage,
  onMakeVideo,
  isGeneratingMedia,
  autoNarration,
  onToggleAutoNarration,
}) => {
  const [messageDraft, setMessageDraft] = useState('');
  const [speakingAs, setSpeakingAs] = useState<'user' | 'narrator' | string>('user');
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [chatHistory.length]);

  const activeCharacterName = useMemo(() => {
    if (speakingAs === 'user') return 'You';
    if (speakingAs === 'narrator') return 'Narrator';
    return characters.find((c) => c.id === speakingAs)?.name || 'Character';
  }, [speakingAs, characters]);

  const handleSend = async () => {
    if (!messageDraft.trim()) return;
    try {
      await onSendMessage(messageDraft.trim(), speakingAs);
      setMessageDraft('');
      if (speakingAs === 'narrator') {
        setSpeakingAs('user');
      }
    } catch (error) {
      console.error('Send failed:', error);
    }
  };

  const handleAutoSpeak = async () => {
    if (speakingAs === 'user' || speakingAs === 'narrator') return;
    try {
      await onSendMessage('', speakingAs);
    } catch (error) {
      console.error('Auto speak failed:', error);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      handleSend();
    }
  };

  const startEditing = useCallback((message: Message) => {
    setEditingMessageId(message.id);
    setEditingText(message.content);
  }, []);

  const saveEdit = () => {
    if (!editingMessageId) return;
    onEditMessage(editingMessageId, editingText);
    setEditingMessageId(null);
    setEditingText('');
  };

  const cancelEdit = () => {
    setEditingMessageId(null);
    setEditingText('');
  };

  const textLocked = isSending || isContinuing;
  const mediaLocked = isGeneratingMedia || textLocked;
  const anythingRunning = textLocked || isGeneratingMedia;

  const renderMessage = (message: Message) => {
    const isEditing = editingMessageId === message.id;
    return (
      <div key={message.id} className={`rounded-2xl border px-4 py-3 shadow-sm transition ${roleStyles[message.role]}`}>
        <div className="mb-2 flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wide text-white/60">{message.characterName || roleLabels[message.role]}</span>
            {message.videoUrl && message.videoUrl.startsWith('generating:') && <span className="text-[10px] text-white/50">Processing video…</span>}
          </div>
          <div className="flex gap-2 text-xs text-white/50">
            <button onClick={() => startEditing(message)} className="hover:text-white">Edit</button>
            <button onClick={() => onDeleteMessage(message.id)} className="hover:text-red-300">Delete</button>
          </div>
        </div>
        {isEditing ? (
          <div className="space-y-2">
            <textarea
              className="w-full rounded-xl border border-white/20 bg-black/30 p-2 text-sm text-white"
              value={editingText}
              onChange={(e) => setEditingText(e.target.value)}
            />
            <div className="flex gap-2">
              <button onClick={saveEdit} className="rounded-lg bg-primary/70 px-3 py-1 text-sm text-white">Save</button>
              <button onClick={cancelEdit} className="rounded-lg border border-white/20 px-3 py-1 text-sm text-white/70">Cancel</button>
            </div>
          </div>
        ) : (
          <p className="whitespace-pre-wrap text-base leading-relaxed text-white/90">{message.content || '…'}</p>
        )}
        {message.imageUrl && !message.imageUrl.startsWith('generating') && (
          <img src={message.imageUrl} alt="Generated scene" className="mt-3 w-full rounded-xl border border-white/10" />
        )}
        {message.videoUrl && !message.videoUrl.startsWith('generating:') && (
          <video controls className="mt-3 w-full rounded-xl border border-white/10">
            <source src={message.videoUrl} />
          </video>
        )}
      </div>
    );
  };

  return (
    <div className="flex h-full flex-1 flex-col bg-gradient-to-b from-secondary to-surface">
      <header className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-3">
          <button onClick={onOpenSidebar} className="rounded-full bg-white/10 px-3 py-1 text-sm text-white/80 transition hover:bg-white/20 md:hidden">
            Menu
          </button>
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-primary">Roleplay session</p>
            <h2 className="text-lg font-semibold text-white">Advanced RP Chat</h2>
          </div>
        </div>
        <button
          onClick={onToggleAutoNarration}
          className={`rounded-full px-4 py-2 text-sm font-semibold transition ${autoNarration ? 'bg-primary/30 text-white' : 'bg-white/10 text-white/70'}`}
        >
          Auto narration {autoNarration ? 'ON' : 'OFF'}
        </button>
      </header>

      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {chatHistory.map(renderMessage)}
        {(isSending || isContinuing) && (
          <div className="flex items-center gap-3 text-sm text-white/70">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary"></span>
            <p>{isSending ? 'Generating reply…' : 'Continuing narration…'}</p>
          </div>
        )}
      </div>

      <div className="border-t border-white/5 bg-black/20 px-4 py-4">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-xs uppercase tracking-widest text-white/60">
          <span>Speaking as: <strong className="text-white">{activeCharacterName}</strong></span>
          {textLocked && <span className="text-primary">Stream in progress…</span>}
          {!textLocked && isGeneratingMedia && <span className="text-white/40">Media generation running…</span>}
        </div>
        <div className="flex flex-wrap gap-3">
          <select
            className="rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white"
            value={speakingAs}
            onChange={(e) => setSpeakingAs(e.target.value)}
          >
            <option value="user">You</option>
            <option value="narrator">Narrator</option>
            {characters.map((character) => (
              <option key={character.id} value={character.id}>
                {character.name}
              </option>
            ))}
          </select>
          <textarea
            className={`flex-1 rounded-2xl border border-white/10 p-3 text-white ${textLocked ? 'bg-black/40' : 'bg-black/30'}`}
            rows={3}
            placeholder={textLocked ? 'Previous response still streaming… you can type anyway.' : 'Write your next message…'}
            value={messageDraft}
            onChange={(e) => setMessageDraft(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={handleSend}
            disabled={!messageDraft.trim()}
            className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-white/10"
          >
            Send
          </button>
          {speakingAs !== 'user' && speakingAs !== 'narrator' && (
            <button
              onClick={handleAutoSpeak}
              disabled={textLocked}
              className="rounded-full border border-primary/40 px-5 py-2 text-sm text-primary hover:bg-primary/10 disabled:cursor-not-allowed"
            >
              Let {activeCharacterName} speak
            </button>
          )}
          <button
            onClick={onContinue}
            disabled={textLocked}
            className="rounded-full border border-white/20 px-5 py-2 text-sm text-white/80 hover:bg-white/10 disabled:cursor-not-allowed"
          >
            Continue narration
          </button>
          <button
            onClick={onStopGeneration}
            disabled={!anythingRunning}
            className="rounded-full border border-red-400/40 px-5 py-2 text-sm text-red-200 disabled:cursor-not-allowed disabled:border-white/10 disabled:text-white/20"
          >
            Stop
          </button>
          {textLocked && (
            <button
              onClick={onForceUnlock}
              className="rounded-full border border-white/20 px-5 py-2 text-sm text-white/80 hover:bg-white/10"
            >
              Force unlock
            </button>
          )}
          <button
            onClick={onMakeImage}
            disabled={mediaLocked}
            className="rounded-full border border-white/20 px-5 py-2 text-sm text-white/80 hover:bg-white/10 disabled:cursor-not-allowed"
          >
            Generate image
          </button>
          <button
            onClick={onMakeVideo}
            disabled={mediaLocked}
            className="rounded-full border border-white/20 px-5 py-2 text-sm text-white/80 hover:bg-white/10 disabled:cursor-not-allowed"
          >
            Generate video
          </button>
        </div>
      </div>
    </div>
  );
};
