// Appwrite Function: Salla Webhook Handler (Easy Mode)
// CommonJS format - works with Appwrite Node runtime
// Schema-compatible version - uses existing collection fields

const { Client, Databases, ID, Query } = require('node-appwrite');

// Configuration
const DATABASE_ID = '6946699d001194236820';
const COLLECTION_ID = 'store_connections';

module.exports = async ({ req, res, log, error }) => {
  log('📨 Request received: ' + req.method);

  // Handle GET (status check)
  if (req.method === 'GET') {
    log('✅ Status check - endpoint ready');
    return res.send(`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><title>AI Smart Assistant</title></head>
      <body style="font-family:Arial;text-align:center;padding:50px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;min-height:100vh;margin:0;">
        <h1>🤖 AI Smart Assistant - علام</h1>
        <p style="font-size:1.2em;">✅ Webhook endpoint is ready!</p>
        <p style="opacity:0.7;">Easy Mode - Waiting for Salla events...</p>
      </body>
      </html>
    `, 200, { 'Content-Type': 'text/html; charset=utf-8' });
  }

  // Handle POST (webhooks)
  if (req.method === 'POST') {
    let payload;
    
    try {
      if (typeof req.body === 'string') {
        payload = JSON.parse(req.body);
      } else if (req.body) {
        payload = req.body;
      } else {
        log('⚠️ Empty body received');
        return res.json({ success: false, error: 'Empty body' }, 400);
      }
    } catch (e) {
      log('❌ JSON parse error: ' + e.message);
      return res.json({ success: false, error: 'Invalid JSON' }, 400);
    }

    const eventType = payload.event || 'unknown';
    log('📩 Event type: ' + eventType);

    // Get merchant ID - try all possible locations
    let merchantId = 'unknown';
    if (payload.merchant && payload.merchant.id) {
      merchantId = String(payload.merchant.id);
    } else if (payload.data && payload.data.merchant && payload.data.merchant.id) {
      merchantId = String(payload.data.merchant.id);
    } else if (payload.data && payload.data.store && payload.data.store.id) {
      merchantId = String(payload.data.store.id);
    } else if (payload.merchant) {
      merchantId = String(payload.merchant);
    }
    
    log('🏪 Merchant ID: ' + merchantId);

    // Initialize Appwrite
    let databases;
    try {
      const client = new Client()
        .setEndpoint('https://fra.cloud.appwrite.io/v1')
        .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
        .setKey(process.env.APPWRITE_API_KEY);
      
      databases = new Databases(client);
      log('✅ Appwrite client initialized');
    } catch (e) {
      log('❌ Appwrite init failed: ' + e.message);
      return res.json({ success: false, error: 'Database connection failed' }, 500);
    }

    // =============================================
    // EVENT: app.store.authorize (MAIN EVENT - Easy Mode)
    // =============================================
    if (eventType === 'app.store.authorize') {
      log('🔐 Processing app.store.authorize event');
      
      const accessToken = payload.data?.access_token || payload.access_token;
      const refreshToken = payload.data?.refresh_token || payload.refresh_token || '';
      const expiresIn = payload.data?.expires_in || 14400;
      
      if (!accessToken) {
        log('❌ No access token in payload');
        return res.json({ success: false, error: 'No access token' }, 400);
      }
      
      log('✅ Access token received: ' + accessToken.substring(0, 15) + '...');

      // Fetch store data from Salla API
      let storeName = 'متجر';
      let products = [];
      let shipping = [];
      let coupons = [];
      let offers = [];

      // Get store info
      try {
        log('📡 Fetching store info...');
        const storeRes = await fetch('https://api.salla.dev/admin/v2/store/info', {
          headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        const storeData = await storeRes.json();
        storeName = storeData.data?.name || 'متجر';
        
        // Try to get merchant ID from store info if still unknown
        if (merchantId === 'unknown' && storeData.data?.id) {
          merchantId = String(storeData.data.id);
          log('✅ Got merchant ID from store info: ' + merchantId);
        }
        
        log('✅ Store name: ' + storeName);
      } catch (e) {
        log('⚠️ Store info error: ' + e.message);
      }

      // Get products
      try {
        log('📡 Fetching products...');
        const productsRes = await fetch('https://api.salla.dev/admin/v2/products?per_page=50', {
          headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        const productsData = await productsRes.json();
        products = (productsData.data || []).map(function(p) {
          return {
            id: p.id,
            name: p.name,
            price: p.price?.amount || 0,
            salePrice: p.sale_price?.amount || null,
            currency: p.price?.currency || 'SAR',
            inStock: p.quantity === null || p.quantity > 0
          };
        });
        log('✅ Products: ' + products.length);
      } catch (e) {
        log('⚠️ Products error: ' + e.message);
      }

      // Get shipping
      try {
        log('📡 Fetching shipping...');
        const shippingRes = await fetch('https://api.salla.dev/admin/v2/shipping/zones', {
          headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        const shippingData = await shippingRes.json();
        shipping = (shippingData.data || []).map(function(z) {
          return { id: z.id, name: z.name, countries: z.countries || [] };
        });
        log('✅ Shipping zones: ' + shipping.length);
      } catch (e) {
        log('⚠️ Shipping error: ' + e.message);
      }

      // Get coupons
      try {
        log('📡 Fetching coupons...');
        const couponsRes = await fetch('https://api.salla.dev/admin/v2/coupons?status=active', {
          headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        const couponsData = await couponsRes.json();
        coupons = (couponsData.data || []).map(function(c) {
          return { id: c.id, code: c.code, type: c.type, discount: c.amount || c.percentage };
        });
        log('✅ Coupons: ' + coupons.length);
      } catch (e) {
        log('⚠️ Coupons error: ' + e.message);
      }

      // Get offers
      try {
        log('📡 Fetching offers...');
        const offersRes = await fetch('https://api.salla.dev/admin/v2/special-offers?status=active', {
          headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        const offersData = await offersRes.json();
        offers = (offersData.data || []).map(function(o) {
          return { id: o.id, name: o.name, discount: o.amount || o.percentage };
        });
        log('✅ Offers: ' + offers.length);
      } catch (e) {
        log('⚠️ Offers error: ' + e.message);
      }

      // Check existing store by merchantId
      let existingDoc = null;
      try {
        const existing = await databases.listDocuments(DATABASE_ID, COLLECTION_ID, [
          Query.equal('merchantId', merchantId)
        ]);
        if (existing.documents.length > 0) {
          existingDoc = existing.documents[0];
          log('📋 Found existing store: ' + existingDoc.$id);
        }
      } catch (e) {
        log('ℹ️ No existing store: ' + e.message);
      }

      // Build notes field with all the cached data (JSON)
      const cachedData = {
        storeName: storeName,
        accessToken: accessToken,
        refreshToken: refreshToken,
        tokenExpiresAt: new Date(Date.now() + expiresIn * 1000).toISOString(),
        products: products,
        shipping: shipping,
        coupons: coupons,
        offers: offers,
        cacheUpdated: new Date().toISOString()
      };

      // Prepare document using EXISTING schema fields:
      // storeConnectionId (required), merchantId, connectionStatus, createdDate, lastActivityDate, notes
      const storeDocument = {
        storeConnectionId: merchantId + '_connection',
        merchantId: merchantId,
        connectionStatus: 'active',
        lastActivityDate: new Date().toISOString(),
        notes: JSON.stringify(cachedData)
      };

      // Save to database
      try {
        if (existingDoc) {
          // Update - don't change createdDate
          await databases.updateDocument(DATABASE_ID, COLLECTION_ID, existingDoc.$id, {
            connectionStatus: 'active',
            lastActivityDate: new Date().toISOString(),
            notes: JSON.stringify(cachedData)
          });
          log('✅ Updated store: ' + merchantId);
        } else {
          // Create new - include createdDate
          storeDocument.createdDate = new Date().toISOString();
          await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), storeDocument);
          log('✅ Created store: ' + merchantId);
        }
      } catch (e) {
        log('❌ Database error: ' + e.message);
        // Log what we tried to save for debugging
        log('📋 Document: ' + JSON.stringify(storeDocument).substring(0, 200) + '...');
        return res.json({ success: false, error: e.message }, 500);
      }

      log('🎉 Store connected!');
      return res.json({
        success: true,
        message: 'Store connected!',
        storeName: storeName,
        products: products.length
      });
    }

    // EVENT: app.installed
    if (eventType === 'app.installed') {
      log('📱 App installed: ' + merchantId);
      return res.json({ success: true, message: 'Installed' });
    }

    // EVENT: app.uninstalled
    if (eventType === 'app.uninstalled') {
      log('🗑️ App uninstalled: ' + merchantId);
      try {
        const existing = await databases.listDocuments(DATABASE_ID, COLLECTION_ID, [
          Query.equal('merchantId', merchantId)
        ]);
        if (existing.documents.length > 0) {
          await databases.updateDocument(DATABASE_ID, COLLECTION_ID, existing.documents[0].$id, {
            connectionStatus: 'inactive'
          });
        }
      } catch (e) {
        log('⚠️ Uninstall error: ' + e.message);
      }
      return res.json({ success: true, message: 'Uninstalled' });
    }

    // Other events
    log('ℹ️ Event: ' + eventType);
    return res.json({ success: true, event: eventType });
  }

  return res.json({ error: 'Method not allowed' }, 405);
};
