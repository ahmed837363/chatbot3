
export enum Role {
  USER = 'user',
  CHARACTER = 'character',
  NARRATOR = 'narrator',
  SYSTEM = 'system',
}

export interface Message {
  id: string;
  role: Role;
  content: string;
  characterId?: string;
  characterName?: string;
  prompt?: string; // The user input that triggered this message
  imageUrl?: string;
  videoUrl?: string; // Can be a final URL or "generating:operation-name"
}

export interface Character {
  id:string;
  name: string;
  description: string;
  instructions: string;
  portraitUrl?: string;
}

export interface Settings {
  modelName: string;
  autoNarration: boolean;
  enableSmarterMemory: boolean;
  userPortraitUrl?: string;
  enableGroupChatter?: boolean;
}

export interface WorldInfo {
  scenario: string;
  storyTracker: string;
}

export type SidebarTab = 'chars' | 'world' | 'setup';

export type MessagePart = 'content' | 'prompt' | 'characterName';

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export {};