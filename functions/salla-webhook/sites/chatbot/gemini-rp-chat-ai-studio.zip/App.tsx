import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatWindow } from './components/ChatWindow';
import { CharacterModal } from './components/CharacterModal';
import { getCharacterReplyStream, getNarrationStream, getEvolvedDescription, getChatSummary, generateImageFromScene, startVideoGeneration, getVideosOperation } from './services/apiService';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Message, Character, Role, Settings, WorldInfo, SidebarTab, MessagePart } from './types';

type SendOptions = {
  skipGroupChatter?: boolean;
  historyOverride?: Message[];
};

function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [chatHistory, setChatHistory] = useLocalStorage<Message[]>('rpchat_history', []);
  const [characters, setCharacters] = useLocalStorage<Character[]>('rpchat_characters', []);
  const [worldInfo, setWorldInfo] = useLocalStorage<WorldInfo>('rpchat_world', { scenario: '', storyTracker: '' });
  const [settings, setSettings] = useLocalStorage<Settings>('rpchat_settings', {
    modelName: 'gemini-1.5-flash',
    autoNarration: true,
    enableSmarterMemory: true,
    userPortraitUrl: '',
    enableGroupChatter: false,
  });
  const [activeSidebarTab, setActiveSidebarTab] = useLocalStorage<SidebarTab>('rpchat_activeTab', 'chars');
  
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [editingCharacter, setEditingCharacter] = useState<Character | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [isContinuing, setIsContinuing] = useState(false);
  const [isGeneratingMedia, setIsGeneratingMedia] = useState(false);
  const [isVeoKeySelected, setIsVeoKeySelected] = useState(false);
  const stopGenerationRef = useRef(false);
  const pendingTimeoutRef = useRef<number | null>(null);
  const releaseLocks = () => {
    stopGenerationRef.current = false;
    setIsSending(false);
    setIsContinuing(false);
    setIsGeneratingMedia(false);
  };

  const annotateHungPlaceholders = (reason: string) => {
    setChatHistory(prev => prev.map(msg => {
      if (msg.content === '' && (msg.role === Role.CHARACTER || msg.role === Role.NARRATOR)) {
        return { ...msg, role: Role.SYSTEM, characterName: undefined, content: reason };
      }
      return msg;
    }));
  };

  const forceUnlock = (reason = 'Generation timed out. Ready for new input.') => {
    releaseLocks();
    annotateHungPlaceholders(reason);
  };

  useEffect(() => {
    const hasVisited = localStorage.getItem('rpchat_has_visited');
    // If it's the first visit OR if they have no characters, set up the default scenario.
    if (!hasVisited || characters.length === 0) {
      // Clear out any default character and scenario to give users a blank slate.
      setCharacters([]);
      setSettings(prev => ({
        ...prev,
        userPortraitUrl: ''
      }));
      setWorldInfo({
        scenario: "",
        storyTracker: ""
      });
      setChatHistory([{
        id: `sys_${Date.now()}`,
        role: Role.SYSTEM,
        content: "Welcome to Gemini RP Chat! Create your first character and define the world in the sidebar to begin your story."
      }]);
      localStorage.setItem('rpchat_has_visited', 'true');
    }
    
    const checkVeoKey = async () => {
        if (window.aistudio) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setIsVeoKeySelected(hasKey);
        }
    };
    checkVeoKey();
    setIsLoaded(true);
  }, []);

  // Video Polling Effect
  useEffect(() => {
    const pendingVideos = chatHistory.filter(m => m.videoUrl?.startsWith('generating:'));
    if (pendingVideos.length === 0) return;

    const pollVideo = async (message: Message) => {
        try {
            const operationName = message.videoUrl!.split(':')[1];
            let operation = await getVideosOperation({ name: operationName });
            
            if (operation.done) {
                if (operation.response) {
                    const downloadLink = operation.response.generatedVideos[0].video.uri;
                    const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                    const videoBlob = await videoResponse.blob();
                    const videoUrl = URL.createObjectURL(videoBlob);
                    setChatHistory(prev => prev.map(m => m.id === message.id ? { ...m, videoUrl, content: 'Video generation complete.' } : m));
                } else {
                    throw new Error(operation.error?.message || "Video generation failed without a specific error.");
                }
                setIsGeneratingMedia(false);
            }
        } catch (error) {
            console.error('Polling error:', error);
            setChatHistory(prev => prev.map(m => m.id === message.id ? { ...m, role: Role.SYSTEM, content: `Video failed: ${(error as Error).message}`, videoUrl: undefined } : m));
            setIsGeneratingMedia(false);
        }
    };

    const intervalId = setInterval(() => {
      chatHistory.forEach(m => {
        if (m.videoUrl?.startsWith('generating:')) {
          pollVideo(m);
        }
      });
    }, 10000);

    return () => clearInterval(intervalId);
  }, [chatHistory, setChatHistory]);


  const addMessage = (newMessage: Omit<Message, 'id'>, id?: string) => {
    setChatHistory(prev => [...prev, { ...newMessage, id: id || `msg_${Date.now()}_${Math.random()}` }]);
  };

  const checkAndSummarizeMemory = async () => {
    if (settings.enableSmarterMemory && chatHistory.length > 40) {
        const toSummarize = chatHistory.slice(0, 20);
        if (toSummarize.some(m => m.content?.includes("Story summary:"))) return;
        
        addMessage({ role: Role.SYSTEM, content: "🧠 Condensing older memories..." });
        const summary = await getChatSummary(settings.modelName, toSummarize);
        const summaryMessage: Message = {
            id: `sys_summary_${Date.now()}`,
            role: Role.SYSTEM,
            content: `Story summary: ${summary}`,
        };
        const remainingHistory = chatHistory.slice(20);
        setChatHistory([summaryMessage, ...remainingHistory]);
    }
  };

  const runNarrationStream = async (historyContext?: Message[]) => {
    const placeholderId = `msg_${Date.now()}_narrator`;
    addMessage({ role: Role.NARRATOR, content: '' }, placeholderId);
    
    const historyForPrompt = historyContext || chatHistory;
    const stream = getNarrationStream(settings.modelName, worldInfo, historyForPrompt);
    let fullNarration = '';
    for await (const chunk of stream) {
      if (stopGenerationRef.current) break;
      fullNarration += chunk;
      setChatHistory(prev => prev.map(msg => 
        msg.id === placeholderId ? { ...msg, content: fullNarration } : msg
      ));
    }
  };
  
  const handleSendMessage = async (messageContent: string, as: string, options?: SendOptions): Promise<Message | void> => {
    stopGenerationRef.current = false;
    if (isSending || isContinuing) {
      forceUnlock('Previous generation cancelled to send a new message.');
    }
    const baseHistory = options?.historyOverride ?? chatHistory;
    if (as === 'user') {
      if (!messageContent.trim()) return;
      const userMessage: Message = { id: `msg_${Date.now()}_user`, role: Role.USER, content: messageContent };
      const newHistory = [...baseHistory, userMessage];
      setChatHistory(newHistory);
      if (settings.autoNarration) {
        // Auto-narration is part of the "sending" flow from the user's perspective.
        stopGenerationRef.current = false;
        setIsSending(true);
        try {
          await runNarrationStream(newHistory);
        } catch (error) {
          if (!stopGenerationRef.current) { addMessage({ role: Role.SYSTEM, content: `Error: ${(error as Error).message}` }); }
          releaseLocks();
        } finally {
          const wasStopped = stopGenerationRef.current;
          setIsSending(false);
          if (!wasStopped) {
            checkAndSummarizeMemory();
          }
        }
      }
      if ((settings.enableGroupChatter ?? false) && !options?.skipGroupChatter) {
        await triggerGroupChatter(newHistory);
      }
      return userMessage;
    }
    
    if (as === 'narrator') {
      if (!messageContent.trim()) return;
      const narrationMessage: Message = { id: `msg_${Date.now()}_narrator_manual`, role: Role.NARRATOR, content: messageContent };
      addMessage(narrationMessage);
      return narrationMessage;
    }

  // Character reply logic
    setIsSending(true);
    const character = characters.find(c => c.id === as);
    if (!character) {
      setIsSending(false);
      return;
    }

    let placeholderId: string | null = null;
    let finalMessage: Message | undefined;
    try {
      let historyForPrompt = [...baseHistory];
      if (messageContent.trim()) {
        historyForPrompt.push({ id: `msg_${Date.now()}_user_context`, role: Role.USER, content: messageContent });
      }

      placeholderId = `msg_${Date.now()}_char`;
      addMessage({ role: Role.CHARACTER, content: '', characterId: character.id, characterName: character.name }, placeholderId);

      const stream = getCharacterReplyStream(settings.modelName, worldInfo, character, historyForPrompt);
      let fullReply = '';
      for await (const chunk of stream) {
        if (stopGenerationRef.current) break;
        fullReply += chunk || '';
        setChatHistory(prev => prev.map(msg => msg.id === placeholderId ? { ...msg, content: fullReply } : msg));
      }

      if (fullReply.trim() === '' && !stopGenerationRef.current) {
        const systemFallback: Message = {
          id: placeholderId,
          role: Role.SYSTEM,
          content: `${character.name} couldn't respond. Try again in a moment.`,
        };
        finalMessage = systemFallback;
        setChatHistory(prev => prev.map(msg =>
          msg.id === placeholderId ? { ...systemFallback } : msg
        ));
      } else if (!stopGenerationRef.current) {
        finalMessage = {
          id: placeholderId,
          role: Role.CHARACTER,
          content: fullReply,
          characterId: character.id,
          characterName: character.name,
        };
        if (settings.autoNarration) {
          // Only trigger auto-narration if the character provided a response.
          const finalHistoryForNarration = [...historyForPrompt, finalMessage];
          await runNarrationStream(finalHistoryForNarration);
        }
      }
    } catch (error) {
      if (!stopGenerationRef.current) {
        if (placeholderId) {
          const errorMessage: Message = {
            id: placeholderId,
            role: Role.SYSTEM,
            content: `Error from ${character.name}: ${(error as Error).message}`,
          };
          finalMessage = errorMessage;
          setChatHistory(prev => prev.map(msg =>
            msg.id === placeholderId ? { ...errorMessage } : msg
          ));
        } else {
          addMessage({ role: Role.SYSTEM, content: `Error: ${(error as Error).message}` });
        }
        releaseLocks();
      } else {
        releaseLocks();
      }
  } finally {
    const wasStopped = stopGenerationRef.current;
    setIsSending(false);
    if (!wasStopped) {
      checkAndSummarizeMemory();
    }
  }
    return finalMessage;
  };

  const triggerGroupChatter = async (startingHistory: Message[]) => {
    if (!characters.length) return;
    let rollingHistory = [...startingHistory];
    for (const character of characters) {
      if (stopGenerationRef.current) break;
      const result = await handleSendMessage('', character.id, {
        skipGroupChatter: true,
        historyOverride: rollingHistory,
      });
      if (result) {
        rollingHistory = [...rollingHistory, result];
      }
    }
  };
  
  const handleContinue = async () => {
    stopGenerationRef.current = false;
    setIsContinuing(true);
    try {
        await runNarrationStream();
    } catch (error) {
        if (!stopGenerationRef.current) {
          addMessage({ role: Role.SYSTEM, content: `Error: ${(error as Error).message}` });
        }
    releaseLocks();
    } finally {
        const wasStopped = stopGenerationRef.current;
        setIsContinuing(false);
        if (!wasStopped) {
          checkAndSummarizeMemory();
        }
    }
  };
  
  const handleStopGeneration = () => {
    stopGenerationRef.current = true;
    setIsSending(false);
    setIsContinuing(false);
    setIsGeneratingMedia(false); // This unlocks the UI immediately.

    // Clean up placeholders from the chat history.
    setChatHistory(prev => {
        const updatedHistory = prev
            // Remove initial placeholders that haven't transitioned to a polling state
            .filter(m => 
                m.content !== '🎨 Generating image...' && 
                m.content !== '🎬 Starting video generation...' &&
                m.content !== '' // Also remove empty text placeholders
            )
            // Update any messages that are already in the polling state to "cancelled"
            .map(m => {
                if (m.videoUrl?.startsWith('generating:')) {
                    return { ...m, videoUrl: undefined, content: 'Video generation cancelled by user.' };
                }
                return m;
            });
        return updatedHistory;
    });
  };
  
  const handleMakeImage = async () => {
    stopGenerationRef.current = false;
    setIsGeneratingMedia(true);
    const placeholderId = `msg_image_placeholder_${Date.now()}`;
    addMessage({ role: Role.SYSTEM, content: '🎨 Generating image...' }, placeholderId);
    try {
      const imageUrl = await generateImageFromScene(settings.modelName, chatHistory, characters, settings.userPortraitUrl);
      if (stopGenerationRef.current) {
        setChatHistory(prev => prev.filter(m => m.id !== placeholderId));
      } else {
        setChatHistory(prev => prev.map(m => m.id === placeholderId ? { ...m, imageUrl, content: '' } : m));
      }
    } catch (error) {
      if (!stopGenerationRef.current) {
        setChatHistory(prev => prev.map(m => m.id === placeholderId ? { ...m, content: `Image generation failed: ${(error as Error).message}` } : m));
      } else {
        setChatHistory(prev => prev.filter(m => m.id !== placeholderId));
      }
      releaseLocks();
    } finally {
      setIsGeneratingMedia(false);
    }
  };

  const handleSelectVeoKey = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setIsVeoKeySelected(true); // Optimistically assume success
    } else {
      alert("API Key selection is not available in this environment.");
    }
  };

  const handleMakeVideo = async () => {
    if (!isVeoKeySelected && window.aistudio) {
        await handleSelectVeoKey();
        return; // Ask user to click again after selecting a key.
    }
    stopGenerationRef.current = false;
    setIsGeneratingMedia(true);
    const placeholderId = `msg_video_placeholder_${Date.now()}`;
    addMessage({ role: Role.SYSTEM, content: '🎬 Starting video generation...' }, placeholderId);
    try {
        const operation = await startVideoGeneration(settings.modelName, chatHistory);
        if (stopGenerationRef.current) {
            setChatHistory(prev => prev.filter(m => m.id !== placeholderId));
            setIsGeneratingMedia(false);
            return;
        }
        setChatHistory(prev => prev.map(m => m.id === placeholderId ? { ...m, videoUrl: `generating:${operation.name}`, content: '' } : m));
    } catch (error) {
        if (stopGenerationRef.current) {
             setChatHistory(prev => prev.filter(m => m.id !== placeholderId));
        } else if ((error as Error).message.includes("Requested entity was not found")) {
            setIsVeoKeySelected(false);
            setChatHistory(prev => prev.map(m => m.id === placeholderId ? { ...m, content: "Video generation failed. Please select a valid VEO-enabled API Key in the AI Studio menu." } : m));
        } else {
            setChatHistory(prev => prev.map(m => m.id === placeholderId ? { ...m, content: `Video generation failed: ${(error as Error).message}` } : m));
        }
        releaseLocks();
    setIsGeneratingMedia(false);
  } finally {
    if (!stopGenerationRef.current) {
      setIsGeneratingMedia(false);
    }
    }
  };

  const handleEditMessage = (id: string, newContent: string, part: MessagePart = 'content') => {
    setChatHistory(prev => prev.map(msg => msg.id === id ? { ...msg, [part]: newContent } : msg));
  };

  const handleDeleteMessage = (id: string) => {
    setChatHistory(prev => prev.filter(msg => msg.id !== id));
  };
  
  const handleSaveCharacter = (character: Character) => {
    setCharacters(prev => prev.some(c => c.id === character.id) ? prev.map(c => c.id === character.id ? character : c) : [...prev, character]);
    setEditingCharacter(null);
  };
  
  const handleEvolveCharacter = async (character: Character) => {
    return await getEvolvedDescription(settings.modelName, character, chatHistory);
  };

  const handleClearChat = () => {
    if (window.confirm('Are you sure you want to clear the entire chat history? This cannot be undone.')) {
        setChatHistory([{
            id: `sys_${Date.now()}`,
            role: Role.SYSTEM,
            content: "Chat history cleared. A new story begins."
        }]);
    }
  };

  const handleUserPortraitChange = (dataUrl: string) => {
    setSettings(prev => ({ ...prev, userPortraitUrl: dataUrl }));
  };

  const handleToggleAutoNarration = () => {
    setSettings(prev => ({ ...prev, autoNarration: !prev.autoNarration }));
  };
  
  useEffect(() => {
    const hasActiveTextStream = chatHistory.some(msg => msg.content === '' && (msg.role === Role.CHARACTER || msg.role === Role.NARRATOR));
    if (!hasActiveTextStream) {
      setIsSending(false);
      setIsContinuing(false);
    }
  }, [chatHistory]);

  useEffect(() => {
    if (!(isSending || isContinuing)) {
      if (pendingTimeoutRef.current) {
        window.clearTimeout(pendingTimeoutRef.current);
        pendingTimeoutRef.current = null;
      }
      return;
    }
    pendingTimeoutRef.current = window.setTimeout(() => {
      forceUnlock('Generation took too long and was cancelled.');
      pendingTimeoutRef.current = null;
    }, 20000);
    return () => {
      if (pendingTimeoutRef.current) {
        window.clearTimeout(pendingTimeoutRef.current);
        pendingTimeoutRef.current = null;
      }
    };
  }, [isSending, isContinuing]);

  if (!isLoaded) return null;

  return (
    <div className="flex h-screen w-screen text-gray-300 font-sans antialiased overflow-hidden">
      {sidebarOpen && <div onClick={() => setSidebarOpen(false)} className="fixed inset-0 bg-black/50 z-30 md:hidden" />}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activeTab={activeSidebarTab}
        setActiveTab={setActiveSidebarTab}
        characters={characters}
        onNewCharacter={() => setEditingCharacter({ id: '', name: '', description: '', instructions: '', portraitUrl: '' })}
        onEditCharacter={(char) => setEditingCharacter(char)}
        worldInfo={worldInfo}
        setWorldInfo={setWorldInfo}
        settings={settings}
        setSettings={setSettings}
        onClearChat={handleClearChat}
        isVeoKeySelected={isVeoKeySelected}
        onSelectVeoKey={handleSelectVeoKey}
        onUserPortraitChange={handleUserPortraitChange}
      />
      <div className={`flex-1 transition-all duration-300 ease-in-out ${sidebarOpen ? 'hidden md:flex' : 'flex'}`}>
        <ChatWindow
          chatHistory={chatHistory}
          characters={characters}
          onSendMessage={handleSendMessage}
          onContinue={handleContinue}
          onStopGeneration={handleStopGeneration}
          onForceUnlock={forceUnlock}
          onEditMessage={handleEditMessage}
          onDeleteMessage={handleDeleteMessage}
          onOpenSidebar={() => setSidebarOpen(true)}
          isSending={isSending}
          isContinuing={isContinuing}
          onMakeImage={handleMakeImage}
          onMakeVideo={handleMakeVideo}
          isGeneratingMedia={isGeneratingMedia}
          autoNarration={settings.autoNarration}
          onToggleAutoNarration={handleToggleAutoNarration}
        />
      </div>
      
      {editingCharacter && (
        <CharacterModal
          character={editingCharacter}
          onSave={handleSaveCharacter}
          onCancel={() => setEditingCharacter(null)}
          onEvolve={handleEvolveCharacter}
        />
      )}
    </div>
  );
}

export default App;
